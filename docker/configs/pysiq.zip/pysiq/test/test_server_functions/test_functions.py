from time import sleep


def foo(n, message):
    sleep(n)
    print(message)
    return message
